import type { ComponentRef, RefObject } from 'react';
import { BlurTargetView } from 'expo-blur';
import { StyleSheet, View } from 'react-native';

type AmbientBackgroundProps = {
  blurTarget: RefObject<ComponentRef<typeof View> | null>;
};

export function AmbientBackground({ blurTarget }: AmbientBackgroundProps) {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <BlurTargetView
        ref={blurTarget}
        pointerEvents="none"
        style={StyleSheet.absoluteFill}>
        <View className="absolute inset-0 bg-black" />
        <View className="absolute -right-[250px] -top-[120px] h-[430px] w-[430px] rounded-full bg-[#0C3A1A]" />
        <View className="absolute -right-[180px] -top-[50px] h-[290px] w-[290px] rounded-full bg-[#0F4A21]" />
        <View className="absolute -right-[150px] top-[330px] h-[220px] w-[220px] rounded-full bg-[#0A2F15]" />
        <View className="absolute -bottom-[40px] -left-[190px] h-[300px] w-[300px] rounded-full bg-[#0B3418]" />
      </BlurTargetView>
    </View>
  );
}
