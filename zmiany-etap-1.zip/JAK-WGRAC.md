# Etap 1: ekran główny (zakładka Treningi)

Skopiuj folder `src/` z tej paczki do katalogu głównego projektu, nadpisując pliki.

| Plik | Co się zmienia |
|---|---|
| `src/app/(tabs)/training/index.tsx` | nowy układ: 🔥 z cyfrą w nagłówku, pasek dni, karta „ZACZNIJ TRENING”, 3 kafelki, plany |
| `src/components/ambient-background.tsx` | tło: czerń + ostre zielone kręgi (działa też na ekranach z `WorkoutScreen`) |
| `src/constants/glass-tokens.json` | **tylko dopisane** tokeny ciemnego szkła (`glass.dark`, `glass.line`, `darkAccent`, `darkGold`, `streakDay`) |
| `src/lib/workout-streak.ts` | **nowy**: passa (dni z rzędu), aktywność tygodnia, minuty w tym tygodniu |

Bez zmian: routing, `use-gym-app`, zapis sesji, `completed_at`, mapa mięśni.

## Po wgraniu

```bash
npx tsc --noEmit
npx expo lint
npx expo start -c
```

`-c` czyści cache — potrzebne, bo w `glass-tokens.json` doszły kolory dla Tailwinda.

## Co sprawdzić

1. Ekran główny: tło z kręgami, karty z ciemnego szkła (kręgi lekko prześwitują).
2. 🔥 z cyfrą obok ustawień — widać tylko przy passie ≥ 1 dzień.
3. Pasek Pn–Nd: dni z treningiem mają 🔥, dziś ma zieloną obwódkę.
4. **START** otwiera „Wybierz trening”; „Wszystkie” też.
5. Kafelki: treningi w tym tygodniu / cel, passa (z rekordem, jeśli jest wyższy), minuty w tym tygodniu.
6. Plany: kliknięcie otwiera trening, „Nowy plan” otwiera kreator; pociągnięcie w dół odświeża.
7. Konto bez sesji: brak 🔥 w nagłówku, kafelek passy pokazuje 🔥 0.

## Jak liczona jest passa

Kolejne dni kalendarzowe (strefa czasowa telefonu) z co najmniej jednym ukończonym treningiem (`completedAt`).
Passa trwa do końca dzisiejszego dnia — brak treningu **dziś** jeszcze jej nie zeruje; zeruje ją dopiero cały dzień bez treningu.
