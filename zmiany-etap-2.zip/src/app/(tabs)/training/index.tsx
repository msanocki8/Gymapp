import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { cssInterop } from 'nativewind';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentProps,
  type ComponentRef,
  type ReactNode,
  type RefObject,
} from 'react';
import {
  ActivityIndicator,
  Animated,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { ScrollViewInstance, ViewStyle } from 'react-native';
import { SymbolView } from 'expo-symbols';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import glassTokens from '@/constants/glass-tokens.json';
import { AmbientBackground } from '@/components/ambient-background';
import { useGymApp } from '@/hooks/use-gym-app';
import type { WorkoutPlan } from '@/hooks/use-gym-app';
import { useAuth } from '@/hooks/use-auth';
import { countWorkoutsThisWeek } from '@/lib/workout-goal';
import { getWorkoutStreak, sumMinutesThisWeek } from '@/lib/workout-streak';

type CrossPlatformShadowStyle = ViewStyle & { boxShadow?: string };
type GlassTone = 'plain' | 'accent' | 'gold';

const cardShadow: CrossPlatformShadowStyle = Platform.OS === 'web'
  ? { boxShadow: '0 10px 30px rgba(0, 0, 0, 0.35)' }
  : {
      shadowColor: '#000000',
      shadowOpacity: 0.3,
      shadowRadius: 18,
      shadowOffset: { width: 0, height: 10 },
      elevation: 4,
    };

const startButtonGlow: CrossPlatformShadowStyle = Platform.OS === 'web'
  ? { boxShadow: '0 0 24px rgba(163, 230, 53, 0.45)' }
  : {
      shadowColor: '#A3E635',
      shadowOpacity: 0.5,
      shadowRadius: 16,
      shadowOffset: { width: 0, height: 0 },
      elevation: 10,
    };

const webGlass = Platform.OS === 'web'
  ? ({ backdropFilter: 'blur(16px) saturate(140%)' } as ViewStyle)
  : undefined;

const blurMethod = Platform.OS === 'android' ? 'dimezisBlurViewSdk31Plus' : undefined;
const LocalBlurTargetContext = createContext<RefObject<ComponentRef<typeof View> | null> | null>(null);

const toneGradients: Record<Exclude<GlassTone, 'plain'>, readonly [string, string]> = {
  accent: [glassTokens.gradients.darkAccent[0], glassTokens.gradients.darkAccent[1]],
  gold: [glassTokens.gradients.darkGold[0], glassTokens.gradients.darkGold[1]],
};
const startButtonGradient = [
  glassTokens.gradients.startButton[0],
  glassTokens.gradients.startButton[1],
] as const;
const heroGradient = [
  glassTokens.gradients.heroCard[0],
  glassTokens.gradients.heroCard[1],
] as const;

cssInterop(LinearGradient, { className: 'style' });

const formatDuration = (minutes: number) => `${minutes} min`;

function polishPlural(count: number, one: string, few: string, many: string) {
  if (count === 1) return one;
  const lastDigit = count % 10;
  const lastTwoDigits = count % 100;
  return lastDigit >= 2 && lastDigit <= 4 && (lastTwoDigits < 12 || lastTwoDigits > 14) ? few : many;
}

const formatExerciseCount = (count: number) =>
  `${count} ${polishPlural(count, 'ćwiczenie', 'ćwiczenia', 'ćwiczeń')}`;
const dayWord = (count: number) => (count === 1 ? 'dzień' : 'dni');

function greetingForHour(hour: number) {
  if (hour < 5) return 'Dobrej nocy,';
  if (hour < 12) return 'Dzień dobry,';
  if (hour < 18) return 'Cześć,';
  return 'Dobry wieczór,';
}

function Reveal({ delay = 0, children }: { delay?: number; children: ReactNode }) {
  const [progress] = useState(() => new Animated.Value(0));

  useEffect(() => {
    Animated.timing(progress, {
      toValue: 1,
      duration: 420,
      delay,
      useNativeDriver: Platform.OS !== 'web',
    }).start();
  }, [delay, progress]);

  return (
    <Animated.View
      style={{
        opacity: progress,
        transform: [{ translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }],
      }}>
      {children}
    </Animated.View>
  );
}

function AppIcon({
  name,
  size,
  color,
}: {
  name: ComponentProps<typeof SymbolView>['name'];
  size: number;
  color: string;
}) {
  return <SymbolView name={name} size={size} tintColor={color} />;
}

function GlassCard({
  children,
  className = '',
  contentClassName = '',
  tone = 'plain',
  radius = 24,
}: {
  children: ReactNode;
  className?: string;
  contentClassName?: string;
  tone?: GlassTone;
  radius?: number;
}) {
  const blurTarget = useContext(LocalBlurTargetContext);
  const borderClass = tone === 'accent'
    ? 'border-neon-lime/[0.22]'
    : tone === 'gold'
      ? 'border-[#FACC15]/[0.32]'
      : 'border-glass-line';

  return (
    <View
      className={`relative w-full overflow-hidden border bg-glass-dark ${borderClass} ${className}`}
      style={[cardShadow, webGlass, { borderRadius: radius }]}>
      {Platform.OS !== 'web' ? (
        <BlurView
          pointerEvents="none"
          blurMethod={blurMethod}
          blurTarget={blurTarget ?? undefined}
          intensity={18}
          tint="dark"
          style={[StyleSheet.absoluteFill, { borderRadius: radius }]}
        />
      ) : null}
      {tone !== 'plain' ? (
        <LinearGradient
          pointerEvents="none"
          colors={toneGradients[tone]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0.75, y: 0.6 }}
          className="absolute inset-0"
          style={{ borderRadius: radius }}
        />
      ) : null}
      <View className={`relative z-10 ${contentClassName}`}>{children}</View>
    </View>
  );
}

function StatTile({
  value,
  unit,
  label,
  tone = 'plain',
}: {
  value: string;
  unit?: string;
  label: string;
  tone?: GlassTone;
}) {
  return (
    <View className="min-w-0 flex-1">
      <GlassCard tone={tone} radius={18} contentClassName="min-h-[78px] justify-between px-[13px] py-[12px]">
        <Text numberOfLines={1} className="text-[21px] font-black text-text-primary">
          {value}
          {unit ? <Text className="text-[11px] font-medium text-text-muted">{unit}</Text> : null}
        </Text>
        <Text numberOfLines={2} className={`text-[11px] leading-[14px] ${tone === 'gold' ? 'font-bold text-[#FDE68A]' : 'text-text-muted'}`}>
          {label}
        </Text>
      </GlassCard>
    </View>
  );
}

function WorkoutPlanCard({
  workout,
  onPress,
}: {
  workout: WorkoutPlan;
  onPress: () => void;
}) {
  const exerciseCount = workout.exercises.length;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Otwórz plan ${workout.name}`}
      onPress={onPress}
      className="w-full active:scale-[0.98] active:opacity-90">
      <GlassCard tone="accent" radius={20} contentClassName="min-h-[72px] flex-row items-center gap-[12px] px-[14px] py-[12px]">
        <View className="h-[44px] w-[44px] items-center justify-center rounded-[14px] border border-white/10 bg-white/[0.07]">
          <AppIcon
            name={{ ios: 'dumbbell.fill', android: 'fitness_center', web: 'fitness_center' }}
            size={19}
            color="#F0ABFC"
          />
        </View>
        <View className="min-w-0 flex-1 gap-1">
          <Text numberOfLines={1} className="text-[15px] font-black text-text-primary">
            {workout.name}
          </Text>
          <Text numberOfLines={1} className="text-[12px] text-text-muted">
            {workout.focus}
          </Text>
        </View>
        <View className="shrink-0 flex-row items-center gap-[9px]">
          <View className="items-end gap-1">
            <Text numberOfLines={1} className="text-[13px] font-extrabold text-text-primary">
              {formatDuration(workout.duration)}
            </Text>
            <Text numberOfLines={1} className="text-[12px] text-text-muted">
              {formatExerciseCount(exerciseCount)}
            </Text>
          </View>
          <AppIcon
            name={{ ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }}
            size={14}
            color="#4ADE80"
          />
        </View>
      </GlassCard>
    </Pressable>
  );
}

export default function TrainingHomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollViewInstance>(null);
  const blurTarget = useRef<ComponentRef<typeof View>>(null);
  const {
    userName,
    plans,
    plansLoading,
    plansError,
    reloadPlans,
    sessions,
    sessionsLoading,
    sessionsError,
    reloadSessions,
  } = useGymApp();
  const { weeklyWorkoutGoal } = useAuth();
  const [refreshing, setRefreshing] = useState(false);

  const completedWorkouts = Math.min(countWorkoutsThisWeek(sessions), weeklyWorkoutGoal);
  const streak = useMemo(() => getWorkoutStreak(sessions), [sessions]);
  const minutesThisWeek = useMemo(() => sumMinutesThisWeek(sessions), [sessions]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([reloadPlans(), reloadSessions()]);
    setRefreshing(false);
  }, [reloadPlans, reloadSessions]);

  useFocusEffect(
    useCallback(() => {
      scrollRef.current?.scrollTo({ y: 0, animated: false });
      void reloadPlans();
      void reloadSessions();
    }, [reloadPlans, reloadSessions]),
  );

  return (
    <SafeAreaView edges={['top']} className="flex-1 overflow-hidden bg-black">
      <AmbientBackground blurTarget={blurTarget} />
      <LocalBlurTargetContext.Provider value={blurTarget}>
        <ScrollView
          ref={scrollRef}
          className="flex-1"
          contentContainerStyle={{
            flexGrow: 1,
            paddingHorizontal: 20,
            paddingTop: 16,
            paddingBottom: 120 + insets.bottom,
          }}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#A3E635" />
          }
          showsVerticalScrollIndicator={false}>
          <View className="mx-auto w-full max-w-[560px] gap-[20px]">
            <View className="flex-row items-center justify-between gap-[12px]">
              <View className="h-[30px] flex-row items-center gap-[7px] rounded-full bg-neon-bright px-[12px]">
                <AppIcon
                  name={{ ios: 'figure.strengthtraining.traditional', android: 'fitness_center', web: 'fitness_center' }}
                  size={14}
                  color="#06210D"
                />
                <Text className="text-[12px] font-black tracking-[1.4px] text-[#06210D]">GYM LOG</Text>
              </View>
              <View className="flex-row items-center gap-[8px]">
                {streak.current > 0 ? (
                  <View
                    accessible
                    accessibilityLabel={`Passa: ${streak.current} ${dayWord(streak.current)} z rzędu`}
                    className="h-[34px] flex-row items-center gap-[5px] rounded-full border border-[#FACC15]/[0.35] bg-[#FACC15]/[0.12] px-[11px]">
                    <Text className="text-[13px]">🔥</Text>
                    <Text className="text-[13px] font-black text-[#FDE68A]">{streak.current}</Text>
                  </View>
                ) : null}
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Ustawienia konta"
                  onPress={() => router.push('/(tabs)/account')}
                  className="h-11 w-11 items-center justify-center rounded-full border border-glass-line bg-glass-dark active:opacity-75">
                  <AppIcon
                    name={{ ios: 'gearshape.fill', android: 'settings', web: 'settings' }}
                    size={19}
                    color="#A3E635"
                  />
                </Pressable>
              </View>
            </View>

            <Text className="text-[28px] font-black leading-[34px] tracking-[-0.6px] text-text-primary" numberOfLines={2}>
              {greetingForHour(new Date().getHours())}{' '}
              <Text className="text-neon-lime">{userName}</Text>
            </Text>

            <Reveal delay={40}>
              <View className="gap-[8px]">
                <View className="flex-row gap-[9px]">
                  <StatTile
                    value={sessionsLoading ? '…' : String(completedWorkouts)}
                    unit={`/${weeklyWorkoutGoal}`}
                    label="w tym tygodniu"
                  />
                  <StatTile
                    tone="gold"
                    value={sessionsLoading ? '…' : `🔥 ${streak.current}`}
                    unit={` ${dayWord(streak.current)}`}
                    label={streak.best > streak.current ? `passa · rekord ${streak.best}` : 'passa'}
                  />
                  <StatTile
                    value={sessionsLoading ? '…' : String(minutesThisWeek)}
                    unit=" min"
                    label="w tym tygodniu"
                  />
                </View>
                {sessionsError ? (
                  <Text className="text-[12px] leading-[18px] text-red-300">
                    Nie udało się pobrać postępów. Pociągnij w dół, aby odświeżyć.
                  </Text>
                ) : null}
              </View>
            </Reveal>

            <Reveal delay={100}>
              <View className="w-full overflow-hidden rounded-[26px] border border-neon-lime/25" style={cardShadow}>
                <LinearGradient
                  pointerEvents="none"
                  colors={heroGradient}
                  locations={[0, 0.6]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  className="absolute inset-0"
                />
                <View
                  pointerEvents="none"
                  className="absolute -right-[40px] -top-[40px] h-[150px] w-[150px] rounded-full bg-neon-lime/[0.14]"
                />
                <View className="w-full p-[20px]">
                  <Text className="text-[11px] font-black tracking-[1.6px] text-neon-lime">CZAS NA RUCH</Text>
                  <Text className="mt-[8px] text-[30px] font-black leading-[34px] tracking-[-0.6px] text-text-primary">
                    ZACZNIJ TRENING
                  </Text>
                  <Text className="mt-[6px] text-[13px] leading-[19px] text-text-muted">
                    Wybierz plan i ruszaj po swoje.
                  </Text>
                  <View className="mt-[18px] w-full overflow-visible rounded-full" style={startButtonGlow}>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Zacznij trening"
                      onPress={() => router.push('/workout-flow')}
                      android_ripple={{ color: 'rgba(0, 0, 0, 0.14)' }}
                      className="min-h-[54px] w-full overflow-hidden rounded-full active:scale-[0.98] active:opacity-90">
                      <LinearGradient
                        colors={startButtonGradient}
                        start={{ x: 0, y: 0.5 }}
                        end={{ x: 1, y: 0.5 }}
                        className="min-h-[54px] w-full flex-row items-center justify-center gap-[10px] rounded-full px-4">
                        <AppIcon
                          name={{ ios: 'play.fill', android: 'play_arrow', web: 'play_arrow' }}
                          size={16}
                          color="#07150C"
                        />
                        <Text className="text-[16px] font-black tracking-[0.8px] text-[#07150C]">START</Text>
                      </LinearGradient>
                    </Pressable>
                  </View>
                </View>
              </View>
            </Reveal>

            <Reveal delay={190}>
              <View className="gap-[12px]">
                <View className="flex-row items-center justify-between gap-[10px] px-px">
                  <Text className="text-[18px] font-black tracking-[-0.3px] text-text-primary">Twoje plany</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Wszystkie plany"
                    onPress={() => router.push('/workout-flow')}
                    className="min-h-[44px] flex-row items-center gap-[5px] pl-3 active:opacity-75">
                    <Text className="text-[13px] font-bold text-neon-lime">Wszystkie</Text>
                    <AppIcon
                      name={{ ios: 'arrow.right', android: 'arrow_forward', web: 'arrow_forward' }}
                      size={13}
                      color="#A3E635"
                    />
                  </Pressable>
                </View>

                {plansLoading ? (
                  <GlassCard contentClassName="min-h-[86px] flex-row items-center justify-center gap-[11px] p-[18px]">
                    <ActivityIndicator color="#A3E635" />
                    <Text className="text-[13px] text-text-primary">Ładowanie Twoich planów…</Text>
                  </GlassCard>
                ) : plansError ? (
                  <GlassCard contentClassName="gap-3 p-[17px]">
                    <Text className="text-[13px] leading-[19px] text-red-200">{plansError}</Text>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => {
                        void reloadPlans();
                        void reloadSessions();
                      }}
                      className="min-h-[44px] justify-center self-start rounded-xl bg-red-400/10 px-[12px]">
                      <Text className="text-[12px] font-bold text-red-300">Spróbuj ponownie</Text>
                    </Pressable>
                  </GlassCard>
                ) : plans.length > 0 ? (
                  <View className="gap-[10px]">
                    {plans.slice(0, 3).map((workout) => (
                      <WorkoutPlanCard
                        key={workout.id}
                        workout={workout}
                        onPress={() => router.push({ pathname: '/workout-session', params: { planId: workout.id } })}
                      />
                    ))}
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Utwórz nowy plan"
                      onPress={() => router.push('/create-workout')}
                      className="min-h-[52px] w-full flex-row items-center justify-center gap-2 rounded-[20px] border border-dashed border-neon-lime/40 active:opacity-75">
                      <AppIcon name={{ ios: 'plus', android: 'add', web: 'add' }} size={16} color="#A3E635" />
                      <Text className="text-[13px] font-extrabold text-neon-lime">Nowy plan</Text>
                    </Pressable>
                  </View>
                ) : (
                  <GlassCard contentClassName="gap-2 p-[18px]">
                    <Text className="text-[14px] font-extrabold text-text-primary">
                      Zacznij od własnego planu
                    </Text>
                    <Text className="text-[12px] leading-[18px] text-text-muted">
                      Dodaj ćwiczenia i zapisz trening na swoim koncie.
                    </Text>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => router.push('/create-workout')}
                      className="mt-[5px] min-h-[44px] self-start flex-row items-center gap-2">
                      <Text className="text-[12px] font-extrabold text-neon-bright">Utwórz plan</Text>
                      <AppIcon name={{ ios: 'plus', android: 'add', web: 'add' }} size={14} color="#4ADE80" />
                    </Pressable>
                  </GlassCard>
                )}
              </View>
            </Reveal>
          </View>
        </ScrollView>
      </LocalBlurTargetContext.Provider>
    </SafeAreaView>
  );
}
