import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useContext, type PropsWithChildren } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import type { StyleProp, ViewStyle } from 'react-native';

import { GlassBlurTargetContext } from '@/components/glass-blur-context';

type CardTone = 'default' | 'featured' | 'plan';
type CrossPlatformShadow = ViewStyle & { boxShadow?: string };

const blurMethod = Platform.OS === 'android' ? 'dimezisBlurViewSdk31Plus' : undefined;
const cardShadow: CrossPlatformShadow = Platform.select({
  web: { boxShadow: '0 10px 30px rgba(0, 0, 0, 0.35)' },
  default: {
    elevation: 4,
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
  },
}) ?? {};
const gradients: Record<CardTone, readonly [string, string, ...string[]]> = {
  default: ['rgba(4,8,6,0)', 'rgba(4,8,6,0)', 'rgba(4,8,6,0)'],
  featured: ['rgba(34,197,94,0.16)', 'rgba(4,8,6,0)', 'rgba(4,8,6,0)'],
  plan: ['rgba(34,197,94,0.14)', 'rgba(4,8,6,0)', 'rgba(4,8,6,0)'],
};
const webGlass = Platform.OS === 'web'
  ? ({ backdropFilter: 'blur(16px) saturate(140%)' } as ViewStyle)
  : undefined;

export function WorkoutFlowGlassCard({
  children,
  tone = 'default',
  style,
  contentStyle,
  glow = false,
}: PropsWithChildren<{
  tone?: CardTone;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  glow?: boolean;
}>) {
  const blurTarget = useContext(GlassBlurTargetContext);

  return (
    <View
      className="relative min-w-0 overflow-hidden rounded-[26px] border"
      style={[styles.shell, cardShadow, webGlass, glow && styles.glow, style]}>
      {Platform.OS !== 'web' ? (
        <BlurView
          pointerEvents="none"
          blurMethod={blurMethod}
          blurTarget={blurTarget ?? undefined}
          intensity={22}
          tint="dark"
          style={[StyleSheet.absoluteFill, styles.blur]}
        />
      ) : null}
      <LinearGradient
        pointerEvents="none"
        colors={gradients[tone]}
        locations={[0, 0.55, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.9, y: 0.7 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.content, contentStyle]}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  shell: {
    backgroundColor: 'rgba(4,8,6,0.52)',
    borderColor: 'rgba(255,255,255,0.10)',
    borderRadius: 26,
    borderWidth: 1,
  },
  glow: {
    borderColor: 'rgba(163,230,53,0.24)',
  },
  blur: {
    borderRadius: 26,
  },
  content: {
    padding: 17,
    position: 'relative',
    zIndex: 1,
  },
});
