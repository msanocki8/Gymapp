import { useRouter } from 'expo-router';
import { ActivityIndicator, Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useMemo, useState } from 'react';
import { SymbolView } from 'expo-symbols';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppBottomBar } from '@/components/app-bottom-bar';
import { MuscleEngagementMap } from '@/components/muscle-engagement-map';
import { exerciseLibrary } from '@/constants/exercise-library';
import { muscleVolumeColors } from '@/constants/muscle-volume';
import { useGymApp } from '@/hooks/use-gym-app';
import type { WorkoutPlan } from '@/hooks/use-gym-app';
import { useAuth } from '@/hooks/use-auth';
import { calculateMuscleVolume } from '@/lib/muscle-volume';
import type { MuscleStatus } from '@/lib/muscle-volume';
import { countWorkoutsThisWeek } from '@/lib/workout-goal';
import { PlanCarousel } from '@/components/plan-carousel';
import { WorkoutFlowGlassCard } from '@/components/workout-flow-glass-card';
import { WorkoutScreen, workoutColors, workoutStyles } from '@/components/workout-ui';

const DAY_MS = 24 * 60 * 60 * 1000;
const MAP_HEIGHT = 250;

const legend: { status: MuscleStatus; label: string }[] = [
  { status: 'no-stimulus', label: '0 serii' },
  { status: 'below', label: 'za mało' },
  { status: 'in-range', label: 'w zakresie' },
  { status: 'warning', label: 'za dużo' },
];

function daysSince(timestamp: number, now = new Date()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const day = new Date(timestamp);
  day.setHours(0, 0, 0, 0);
  return Math.max(0, Math.round((today.getTime() - day.getTime()) / DAY_MS));
}

function exerciseCountLabel(count: number) {
  if (count === 1) return '1 ćw.';
  return `${count} ćw.`;
}

export function WorkoutFlow() {
  const router = useRouter();
  const {
    plans,
    plansLoading,
    plansError,
    reloadPlans,
    deletePlan,
    sessions,
    sessionsLoading,
    sessionsError,
  } = useGymApp();
  const { weeklyWorkoutGoal } = useAuth();
  const insets = useSafeAreaInsets();
  const [deletingPlanId, setDeletingPlanId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const confirmDeletePlan = (plan: WorkoutPlan) => {
    const message = `Czy na pewno chcesz usunąć plan „${plan.name}”?`;
    const onConfirm = () => {
      setDeletingPlanId(plan.id);
      setDeleteError(null);
      void deletePlan(plan.id)
        .catch((error: unknown) => {
          setDeleteError(error instanceof Error ? error.message : 'Nie udało się usunąć planu.');
        })
        .finally(() => setDeletingPlanId(null));
    };

    if (Platform.OS === 'web') {
      if (typeof window !== 'undefined' && window.confirm(message)) onConfirm();
      return;
    }

    Alert.alert('Usunąć plan?', message, [
      { text: 'Anuluj', style: 'cancel' },
      { text: 'Usuń', style: 'destructive', onPress: onConfirm },
    ]);
  };

  const returnToTraining = () => {
    router.replace('/(tabs)/training');
  };

  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setHours(0, 0, 0, 0);
  startOfWeek.setDate(startOfWeek.getDate() - ((startOfWeek.getDay() + 6) % 7));
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(endOfWeek.getDate() + 7);
  const sessionsThisWeek = sessions.filter((session) =>
    session.completedAt >= startOfWeek.getTime() && session.completedAt < endOfWeek.getTime()
  );
  const completedThisWeek = Math.min(countWorkoutsThisWeek(sessions), weeklyWorkoutGoal);
  const completedPlanNamesThisWeek = new Set(
    sessionsThisWeek.map((session) => session.name.trim().toLocaleLowerCase('pl-PL')),
  );
  const nextPlan = plans.find(
    (plan) => !completedPlanNamesThisWeek.has(plan.name.trim().toLocaleLowerCase('pl-PL')),
  );
  const lastCompletedAt = sessions.reduce<number | null>(
    (latest, session) => (latest === null || session.completedAt > latest ? session.completedAt : latest),
    null,
  );
  const daysSinceLast = lastCompletedAt === null ? null : daysSince(lastCompletedAt, today);

  const localTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const weeklyVolumes = useMemo(() => calculateMuscleVolume({
    exercises: [],
    sessions: sessions.map((session) => ({
      completedAt: session.completedAt,
      exercisePerformance: session.exercisePerformance?.map((exercise) => ({
        exerciseId: exercise.exerciseId ?? exerciseLibrary.find((item) => item.name === exercise.name)?.id,
        name: exercise.name,
        sets: exercise.sets.map((set) => ({ ...set, completed: true })),
      })),
    })),
    period: 'week',
    timeZone: localTimeZone,
  }), [sessions, localTimeZone]);
  const hasWeeklyVolume = weeklyVolumes.some((muscle) => muscle.performedSets > 0);

  return (
    <WorkoutScreen maxWidth={820} edges={['top']}>
      <View style={styles.screenContent}>
        <ScrollView
          style={workoutStyles.page}
          contentContainerStyle={[styles.pageContent, { paddingBottom: 100 + insets.bottom }]}
          showsVerticalScrollIndicator={false}>
          <View className="w-full min-w-0 self-center" style={styles.page}>
            <View style={styles.pageHeader}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Wróć do treningów"
                onPress={returnToTraining}
                style={({ pressed }) => [styles.headerIconButton, pressed && styles.pressed]}>
                <SymbolView name={{ ios: 'arrow.left', android: 'arrow_back', web: 'arrow_back' }} size={18} tintColor="#A3E635" />
              </Pressable>
              <View style={styles.pageHeaderCopy}>
                <Text style={styles.pageEyebrow}>CZAS NA RUCH</Text>
                <Text style={styles.pageTitle}>Wybierz trening</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Ustawienia konta"
                onPress={() => router.push('/(tabs)/account')}
                style={({ pressed }) => [styles.headerIconButton, pressed && styles.pressed]}>
                <SymbolView name={{ ios: 'gearshape.fill', android: 'settings', web: 'settings' }} size={18} tintColor="#A3E635" />
              </Pressable>
            </View>

            {nextPlan && !plansLoading && !plansError && !sessionsLoading && !sessionsError ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Na dziś: ${nextPlan.name}. Rozpocznij trening`}
                onPress={() => router.push({ pathname: '/workout-session', params: { planId: nextPlan.id } })}
                style={({ pressed }) => pressed && styles.pressed}>
                <WorkoutFlowGlassCard tone="featured" glow contentStyle={styles.todayBar}>
                  <View style={styles.todayBadge}>
                    <View style={styles.todayBadgeDot} />
                    <Text style={styles.todayBadgeText}>NA DZIŚ</Text>
                  </View>
                  <Text numberOfLines={1} style={styles.todayName}>{nextPlan.name}</Text>
                  <Text numberOfLines={1} style={styles.todayMeta}>
                    {nextPlan.duration} min · {exerciseCountLabel(nextPlan.exercises.length)}
                  </Text>
                  <SymbolView name={{ ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }} size={14} tintColor="#A3E635" />
                </WorkoutFlowGlassCard>
              </Pressable>
            ) : null}

            <WorkoutFlowGlassCard contentStyle={styles.mapCard}>
              <View style={styles.mapHeader}>
                <Text style={styles.mapEyebrow}>TWOJE MIĘŚNIE · TEN TYDZIEŃ</Text>
                {sessionsLoading ? <ActivityIndicator color="#A3E635" size="small" /> : null}
              </View>
              <View style={styles.mapRow}>
                {(['front', 'back'] as const).map((view) => (
                  <View key={view} style={styles.mapColumn}>
                    <MuscleEngagementMap
                      view={view}
                      onViewChange={() => undefined}
                      volumes={weeklyVolumes}
                      showViewToggle={false}
                      height={MAP_HEIGHT}
                    />
                    <Text style={styles.mapViewLabel}>{view === 'front' ? 'PRZÓD' : 'TYŁ'}</Text>
                  </View>
                ))}
              </View>
              <View style={styles.legend}>
                {legend.map((item) => (
                  <View key={item.status} style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: muscleVolumeColors[item.status] }]} />
                    <Text style={styles.legendText}>{item.label}</Text>
                  </View>
                ))}
              </View>
              {sessionsError ? (
                <Text accessibilityRole="alert" style={styles.mapError}>
                  Nie udało się pobrać treningów, więc mapa może być niepełna.
                </Text>
              ) : !sessionsLoading && !hasWeeklyVolume ? (
                <Text style={styles.mapHint}>
                  Ukończ trening w tym tygodniu, a trenowane partie zaświecą się na sylwetce.
                </Text>
              ) : null}
            </WorkoutFlowGlassCard>

            {plans.length === 0 && !plansLoading && !plansError ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Stwórz własny plan"
                onPress={() => router.push('/create-workout')}
                style={({ pressed }) => pressed && styles.pressed}
              >
                <WorkoutFlowGlassCard tone="featured" contentStyle={styles.createCard}>
                  <View style={styles.createIcon}>
                    <Text style={styles.createIconText}>+</Text>
                  </View>
                  <View style={styles.createCopy}>
                    <Text style={styles.createTitle}>Stwórz własny plan</Text>
                    <Text style={styles.createSubtitle}>Dodaj nazwę i ćwiczenia</Text>
                  </View>
                  <Text style={styles.createArrow}>›</Text>
                </WorkoutFlowGlassCard>
              </Pressable>
            ) : null}

            {plansLoading ? (
              <View className="flex-row items-center justify-center gap-2" style={styles.loadingRow}>
                <ActivityIndicator color="#A3E635" size="small" />
                <Text style={styles.loadingText}>Pobieranie zapisanych planów…</Text>
              </View>
            ) : null}

            {plansError ? (
              <WorkoutFlowGlassCard contentStyle={styles.errorCard}>
                <Text accessibilityRole="alert" style={styles.errorText}>{plansError}</Text>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => { void reloadPlans(); }}
                  style={({ pressed }) => [styles.retryButton, pressed && styles.pressed]}>
                  <Text style={styles.retryText}>Spróbuj ponownie</Text>
                </Pressable>
              </WorkoutFlowGlassCard>
            ) : null}

            {deleteError ? (
              <Text accessibilityRole="alert" style={styles.errorText}>{deleteError}</Text>
            ) : null}

            {plans.length > 0 ? (
              <PlanCarousel
                plans={plans}
                onEdit={(plan) => router.push({ pathname: '/create-workout', params: { planId: plan.id } })}
                onDelete={confirmDeletePlan}
                deletingPlanId={deletingPlanId}
              />
            ) : !plansLoading && !plansError ? (
              <WorkoutFlowGlassCard glow tone="featured" contentStyle={styles.emptyCard}>
                <Text className="w-full min-w-0 shrink" style={styles.emptyTitle} numberOfLines={2} ellipsizeMode="tail">Nie masz jeszcze planu</Text>
                <Text className="w-full min-w-0 shrink" style={styles.emptyText}>
                  Utwórz własną rozpiskę i pojawi się tutaj.
                </Text>
              </WorkoutFlowGlassCard>
            ) : null}

            <View style={styles.statsRow}>
              <WorkoutFlowGlassCard style={styles.statCard} contentStyle={styles.statContent}>
                <Text numberOfLines={1} style={styles.statValue}>
                  {sessionsLoading
                    ? '…'
                    : daysSinceLast === null
                      ? '—'
                      : daysSinceLast === 0
                        ? 'dziś'
                        : String(daysSinceLast)}
                  {!sessionsLoading && daysSinceLast !== null && daysSinceLast > 0 ? (
                    <Text style={styles.statUnit}>{daysSinceLast === 1 ? ' dzień' : ' dni'}</Text>
                  ) : null}
                </Text>
                <Text numberOfLines={2} style={styles.statLabel}>od ostatniego</Text>
              </WorkoutFlowGlassCard>
              <WorkoutFlowGlassCard style={styles.statCard} contentStyle={styles.statContent}>
                <Text numberOfLines={1} style={styles.statValue}>{plansLoading ? '…' : plans.length}</Text>
                <Text numberOfLines={2} style={styles.statLabel}>planów</Text>
              </WorkoutFlowGlassCard>
              <WorkoutFlowGlassCard style={styles.statCard} contentStyle={styles.statContent}>
                <Text numberOfLines={1} style={styles.statValue}>
                  {sessionsLoading ? '…' : completedThisWeek}
                  <Text style={styles.statUnit}>/{weeklyWorkoutGoal}</Text>
                </Text>
                <Text numberOfLines={2} style={styles.statLabel}>w tym tygodniu</Text>
              </WorkoutFlowGlassCard>
            </View>
          </View>
        </ScrollView>
        <AppBottomBar
          activeTab="training"
          bottomInset={insets.bottom}
          onNavigate={(tab) => {
            if (tab === 'training') returnToTraining();
            if (tab === 'history') router.replace('/(tabs)/history');
            if (tab === 'account') router.replace('/(tabs)/account');
          }}
        />
      </View>
    </WorkoutScreen>
  );
}

const styles = StyleSheet.create({
  screenContent: {
    flex: 1,
  },
  pageContent: {
    flexGrow: 1,
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  page: {
    alignSelf: 'center',
    gap: 14,
    maxWidth: 760,
    width: '100%',
  },
  pageHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 12,
    minHeight: 50,
  },
  pageHeaderCopy: {
    flex: 1,
    minWidth: 0,
  },
  pageEyebrow: {
    color: '#A3E635',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: 3,
  },
  pageTitle: {
    color: workoutColors.text,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  headerIconButton: {
    alignItems: 'center',
    backgroundColor: 'rgba(4,8,6,0.52)',
    borderColor: 'rgba(163,230,53,0.3)',
    borderRadius: 22,
    borderWidth: 1,
    height: 44,
    justifyContent: 'center',
    width: 44,
  },
  todayBar: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
    minHeight: 56,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  todayBadge: {
    alignItems: 'center',
    backgroundColor: 'rgba(163,230,53,0.1)',
    borderColor: 'rgba(163,230,53,0.4)',
    borderRadius: 99,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  todayBadgeDot: {
    backgroundColor: '#A3E635',
    borderRadius: 3,
    height: 6,
    width: 6,
  },
  todayBadgeText: {
    color: '#D9F99D',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  todayName: {
    color: workoutColors.text,
    flexShrink: 1,
    fontSize: 16,
    fontWeight: '900',
  },
  todayMeta: {
    color: workoutColors.muted,
    flex: 1,
    fontSize: 12,
    minWidth: 0,
    textAlign: 'right',
  },
  mapCard: {
    gap: 8,
    paddingBottom: 14,
    paddingHorizontal: 12,
    paddingTop: 14,
  },
  mapHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    minHeight: 20,
    paddingHorizontal: 4,
  },
  mapEyebrow: {
    color: '#A3E635',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.4,
  },
  mapRow: {
    flexDirection: 'row',
    gap: 4,
  },
  mapColumn: {
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  mapViewLabel: {
    color: '#6F7B73',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginTop: 2,
  },
  legend: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
    marginTop: 4,
  },
  legendItem: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 5,
  },
  legendDot: {
    borderRadius: 4,
    height: 8,
    width: 8,
  },
  legendText: {
    color: '#B8C2BB',
    fontSize: 11,
  },
  mapHint: {
    color: workoutColors.muted,
    fontSize: 12,
    lineHeight: 17,
    paddingHorizontal: 6,
    textAlign: 'center',
  },
  mapError: {
    color: '#fca5a5',
    fontSize: 12,
    lineHeight: 17,
    textAlign: 'center',
  },
  createCard: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 14,
    padding: 17,
  },
  createIcon: {
    alignItems: 'center',
    backgroundColor: 'rgba(163,230,53,0.12)',
    borderColor: 'rgba(163,230,53,0.32)',
    borderRadius: 16,
    borderWidth: 1,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  createIconText: {
    color: '#A3E635',
    fontSize: 24,
    fontWeight: '700',
  },
  createCopy: {
    flex: 1,
    gap: 4,
    minWidth: 0,
  },
  createTitle: {
    color: workoutColors.text,
    fontSize: 15,
    fontWeight: '800',
  },
  createSubtitle: {
    color: workoutColors.muted,
    fontSize: 12,
  },
  createArrow: {
    color: '#A3E635',
    fontSize: 26,
    fontWeight: '500',
    marginTop: -3,
  },
  loadingRow: {
    minHeight: 44,
  },
  loadingText: {
    color: workoutColors.muted,
    fontSize: 12,
  },
  errorCard: {
    gap: 10,
    padding: 16,
  },
  errorText: {
    color: '#fecaca',
    fontSize: 12,
    lineHeight: 18,
  },
  retryButton: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    justifyContent: 'center',
    minHeight: 44,
    paddingHorizontal: 14,
  },
  retryText: {
    color: workoutColors.text,
    fontSize: 12,
    fontWeight: '800',
  },
  emptyCard: {
    gap: 7,
    padding: 18,
  },
  emptyTitle: {
    color: workoutColors.text,
    fontSize: 18,
    fontWeight: '800',
  },
  emptyText: {
    color: workoutColors.muted,
    fontSize: 12,
    lineHeight: 18,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 9,
  },
  statCard: {
    borderRadius: 18,
    flex: 1,
  },
  statContent: {
    gap: 4,
    justifyContent: 'space-between',
    minHeight: 76,
    paddingHorizontal: 13,
    paddingVertical: 12,
  },
  statValue: {
    color: workoutColors.text,
    fontSize: 21,
    fontWeight: '900',
  },
  statUnit: {
    color: workoutColors.muted,
    fontSize: 11,
    fontWeight: '500',
  },
  statLabel: {
    color: workoutColors.muted,
    fontSize: 11,
    lineHeight: 14,
  },
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.985 }],
  },
});
