import { useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import type { NativeScrollEvent, NativeSyntheticEvent, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SymbolView } from 'expo-symbols';
import { useRouter } from 'expo-router';

import type { WorkoutPlan } from '@/hooks/use-gym-app';

type WebScrollSnapStyle = ViewStyle & { scrollSnapType?: string };
type WebItemSnapStyle = ViewStyle & { scrollSnapAlign?: string };

const CARD_GAP = 10;
const HORIZONTAL_PADDING = 0;
const CARD_WIDTH = 272;

const webScrollSnapStyle: WebScrollSnapStyle = Platform.OS === 'web'
  ? { scrollSnapType: 'x mandatory' }
  : {};

const webItemSnapStyle: WebItemSnapStyle = Platform.OS === 'web'
  ? { scrollSnapAlign: 'start' }
  : {};

const startGlow: ViewStyle & { boxShadow?: string } = Platform.OS === 'web'
  ? { boxShadow: '0 0 18px rgba(163, 230, 53, 0.4)' }
  : {
      shadowColor: '#A3E635',
      shadowOpacity: 0.45,
      shadowRadius: 12,
      shadowOffset: { width: 0, height: 0 },
      elevation: 6,
    };

function formatExerciseCount(count: number) {
  if (count === 1) return '1 ćwiczenie';
  const lastDigit = count % 10;
  const lastTwoDigits = count % 100;
  return `${count} ${lastDigit >= 2 && lastDigit <= 4 && (lastTwoDigits < 12 || lastTwoDigits > 14) ? 'ćwiczenia' : 'ćwiczeń'}`;
}

function PlanCard({
  plan,
  width,
  onPress,
  onEdit,
  onDelete,
  deleting,
}: {
  plan: WorkoutPlan;
  width: number;
  onPress: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  deleting: boolean;
}) {
  const badge = plan.focus.split('·')[0]?.trim();
  const exerciseRows = plan.exerciseConfigs?.length
    ? plan.exerciseConfigs.slice(0, 2).map((exercise) => ({
        name: exercise.name,
        details: exercise.sets.length
          ? `${exercise.sets.length} × ${exercise.sets[0]?.reps || '—'}`
          : null,
      }))
    : plan.exercises.slice(0, 2).map((name) => ({ name, details: null }));
  const remainingCount = Math.max(0, plan.exercises.length - exerciseRows.length);

  return (
    <View style={[webItemSnapStyle, { width }, styles.planCard]}>
      <LinearGradient
        pointerEvents="none"
        colors={['#1E4A28', '#0F1F14']}
        locations={[0, 0.6]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View pointerEvents="none" style={styles.planOrb} />

      <View style={styles.planTop}>
        <Text style={styles.planEyebrow}>PLAN</Text>
        {badge ? (
          <View style={styles.planBadge}>
            <Text numberOfLines={1} style={styles.planBadgeText}>{badge}</Text>
          </View>
        ) : null}
      </View>

      <Text numberOfLines={2} ellipsizeMode="tail" style={styles.planTitle}>
        {plan.name}
      </Text>

      <View style={styles.metaRow}>
        <View style={styles.metaChip}>
          <SymbolView name={{ ios: 'timer', android: 'timer', web: 'timer' }} size={12} tintColor="#E5F5E8" />
          <Text style={styles.metaChipText}>{plan.duration} min</Text>
        </View>
        <View style={styles.metaChip}>
          <Text style={styles.metaChipText}>{formatExerciseCount(plan.exercises.length)}</Text>
        </View>
      </View>

      <View style={styles.exerciseRows}>
        {[0, 1].map((index) => {
          const exercise = exerciseRows[index];
          return (
            <View key={exercise?.name ?? `empty-${index}`} style={styles.exerciseRow}>
              <Text numberOfLines={1} style={styles.exerciseName}>
                {exercise?.name ?? ''}
              </Text>
              <Text numberOfLines={1} style={styles.exerciseDetails}>
                {exercise?.details ?? ''}
              </Text>
            </View>
          );
        })}
        <Text style={styles.remaining}>{remainingCount > 0 ? `+ ${remainingCount} kolejnych` : ' '}</Text>
      </View>

      <View style={styles.cardActionsContent}>
        {onEdit || onDelete ? (
          <View style={styles.secondaryActions}>
            {onEdit ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Edytuj plan ${plan.name}`}
                onPress={onEdit}
                style={({ pressed }) => [styles.secondaryButton, pressed && styles.cardPressed]}>
                <SymbolView
                  name={{ ios: 'pencil', android: 'edit', web: 'edit' }}
                  size={15}
                  tintColor="#D1D9D3"
                />
              </Pressable>
            ) : null}
            {onDelete ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Usuń plan ${plan.name}`}
                accessibilityState={{ disabled: deleting }}
                disabled={deleting}
                onPress={onDelete}
                style={({ pressed }) => [styles.secondaryButton, styles.deleteButton, pressed && styles.cardPressed]}>
                {deleting ? (
                  <ActivityIndicator color="#fca5a5" size="small" />
                ) : (
                  <SymbolView
                    name={{ ios: 'trash', android: 'delete', web: 'delete' }}
                    size={15}
                    tintColor="#fca5a5"
                  />
                )}
              </Pressable>
            ) : null}
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Rozpocznij trening: ${plan.name}`}
          onPress={onPress}
          style={({ pressed }) => [styles.startButtonPressable, startGlow, pressed && styles.startPressed]}>
          <LinearGradient
            colors={['#22c55e', '#a3e635']}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={styles.startButton}>
            <SymbolView
              name={{ ios: 'play.fill', android: 'play_arrow', web: 'play_arrow' }}
              size={14}
              tintColor="#07150C"
            />
            <Text style={styles.startButtonText}>Start</Text>
          </LinearGradient>
        </Pressable>
      </View>
    </View>
  );
}

export function PlanCarousel({
  plans,
  onEdit,
  onDelete,
  deletingPlanId,
}: {
  plans: WorkoutPlan[];
  onEdit?: (plan: WorkoutPlan) => void;
  onDelete?: (plan: WorkoutPlan) => void;
  deletingPlanId?: string | null;
}) {
  const router = useRouter();
  const { width: screenWidth } = useWindowDimensions();
  const [viewportWidth, setViewportWidth] = useState(0);
  const [activeIndex, setActiveIndex] = useState(0);
  const activeIndexRef = useRef(0);
  const measuredWidth = viewportWidth || Math.min(screenWidth, 560);
  const cardWidth = plans.length === 1
    ? Math.max(measuredWidth - HORIZONTAL_PADDING * 2, 0)
    : Math.min(CARD_WIDTH, screenWidth * 0.8);
  const snapInterval = cardWidth + CARD_GAP;

  function updateActiveIndex(event: NativeSyntheticEvent<NativeScrollEvent>) {
    if (snapInterval <= 0) return;
    const nextIndex = Math.min(
      plans.length - 1,
      Math.max(0, Math.round(event.nativeEvent.contentOffset.x / snapInterval)),
    );
    if (nextIndex !== activeIndexRef.current) {
      activeIndexRef.current = nextIndex;
      setActiveIndex(nextIndex);
    }
  }

  if (plans.length === 0) return null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text numberOfLines={1} style={styles.headerTitle}>
          TWOJE PLANY · {plans.length}
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Nowy plan"
          onPress={() => router.push('/create-workout')}
          style={({ pressed }) => pressed && styles.headerButtonPressed}>
          <LinearGradient
            colors={['#bef264', '#84e04a']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.headerButton}>
            <SymbolView
              name={{ ios: 'plus', android: 'add', web: 'add' }}
              size={14}
              tintColor="#1a2e05"
            />
            <Text style={styles.headerButtonText}>Nowy plan</Text>
          </LinearGradient>
        </Pressable>
      </View>

      <FlatList
        horizontal
        data={plans}
        keyExtractor={(plan) => plan.id}
        renderItem={({ item }) => (
          <PlanCard
            plan={item}
            width={cardWidth}
            onEdit={onEdit ? () => onEdit(item) : undefined}
            onDelete={onDelete ? () => onDelete(item) : undefined}
            deleting={deletingPlanId === item.id}
            onPress={() => router.push({
              pathname: '/workout-session',
              params: { planId: item.id },
            })}
          />
        )}
        initialNumToRender={4}
        maxToRenderPerBatch={4}
        windowSize={5}
        ItemSeparatorComponent={() => <View style={{ width: CARD_GAP }} />}
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={plans.length > 1 ? snapInterval : undefined}
        snapToAlignment="start"
        nestedScrollEnabled
        scrollEventThrottle={50}
        onScroll={updateActiveIndex}
        onMomentumScrollEnd={updateActiveIndex}
        onLayout={(event) => {
          const nextWidth = event.nativeEvent.layout.width;
          setViewportWidth((current) => current === nextWidth ? current : nextWidth);
        }}
        style={[styles.list, webScrollSnapStyle]}
        contentContainerStyle={styles.listContent}
      />

      {plans.length >= 2 && plans.length <= 5 ? (
        <View style={styles.pagination} accessibilityLabel={`Plan ${activeIndex + 1} z ${plans.length}`}>
          {plans.map((plan, index) => (
            <View
              key={plan.id}
              style={[styles.dot, index === activeIndex ? styles.activeDot : styles.inactiveDot]}
            />
          ))}
        </View>
      ) : plans.length > 5 ? (
        <Text style={styles.pageCount}>{activeIndex + 1} / {plans.length}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  metaChipText: {
    color: '#E5F5E8',
    fontSize: 12,
    fontWeight: '600',
  },
  metaChip: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 999,
    flexDirection: 'row',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  metaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
  },
  planOrb: {
    backgroundColor: 'rgba(163,230,53,0.13)',
    borderRadius: 70,
    height: 140,
    position: 'absolute',
    right: -40,
    top: -40,
    width: 140,
  },
  planEyebrow: {
    color: '#A3E635',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.4,
  },
  remaining: {
    color: '#A3E635',
    fontSize: 11,
    fontWeight: '700',
    height: 16,
  },
  startPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  container: {
    gap: 12,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'space-between',
    minHeight: 36,
    paddingHorizontal: 1,
  },
  headerTitle: {
    color: '#A3E635',
    flex: 1,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.6,
  },
  headerButton: {
    alignItems: 'center',
    borderRadius: 999,
    flexDirection: 'row',
    gap: 5,
    justifyContent: 'center',
    minHeight: 40,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  headerButtonText: {
    color: '#1a2e05',
    fontSize: 12,
    fontWeight: '800',
  },
  headerButtonPressed: {
    opacity: 0.82,
  },
  list: {
    flexGrow: 0,
    width: '100%',
  },
  startButtonPressable: {
    borderRadius: 999,
    flex: 1,
    minWidth: 0,
  },
  listContent: {
    paddingHorizontal: HORIZONTAL_PADDING,
  },
  cardPressed: {
    opacity: 0.8,
  },
  cardActionsContent: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 8,
    marginTop: 4,
    minHeight: 46,
  },
  secondaryActions: {
    alignItems: 'center',
    flexDirection: 'row',
    flexShrink: 0,
    gap: 8,
  },
  secondaryButton: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    borderWidth: 1,
    height: 46,
    justifyContent: 'center',
    width: 44,
  },
  deleteButton: {
    backgroundColor: 'rgba(248,113,113,0.08)',
    borderColor: 'rgba(248,113,113,0.4)',
  },
  exerciseRows: {
    borderTopColor: 'rgba(255,255,255,0.10)',
    borderTopWidth: StyleSheet.hairlineWidth,
    gap: 4,
    paddingTop: 10,
  },
  exerciseRow: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 8,
    height: 20,
    justifyContent: 'space-between',
    minWidth: 0,
  },
  exerciseName: {
    color: '#E5ECE7',
    flex: 1,
    fontSize: 13,
    minWidth: 0,
  },
  exerciseDetails: {
    color: '#9AA69F',
    flexShrink: 0,
    fontSize: 12,
    maxWidth: '38%',
    textAlign: 'right',
  },
  startButton: {
    alignItems: 'center',
    borderRadius: 999,
    flexDirection: 'row',
    gap: 8,
    height: 46,
    justifyContent: 'center',
    minWidth: 0,
    paddingHorizontal: 12,
    width: '100%',
  },
  startButtonText: {
    color: '#07150C',
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  pagination: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 6,
    justifyContent: 'center',
    minHeight: 6,
    marginBottom: 12,
  },
  dot: {
    borderRadius: 3,
    height: 6,
  },
  activeDot: {
    backgroundColor: '#A3E635',
    width: 22,
  },
  inactiveDot: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    width: 6,
  },
  pageCount: {
    color: '#9ca3af',
    fontSize: 11,
    marginBottom: 12,
    textAlign: 'center',
  },
  planTop: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    minHeight: 26,
  },
  planBadge: {
    backgroundColor: 'rgba(163,230,53,0.10)',
    borderColor: 'rgba(163,230,53,0.4)',
    borderRadius: 999,
    borderWidth: 1,
    maxWidth: '68%',
    paddingHorizontal: 9,
    paddingVertical: 4,
  },
  planBadgeText: {
    color: '#D9F99D',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  planCard: {
    borderColor: 'rgba(163,230,53,0.28)',
    borderRadius: 26,
    borderWidth: 1,
    gap: 10,
    overflow: 'hidden',
    padding: 18,
    ...Platform.select({
      web: { boxShadow: '0 12px 30px rgba(0, 0, 0, 0.4)' },
      default: {
        elevation: 5,
        shadowColor: '#000000',
        shadowOpacity: 0.3,
        shadowRadius: 16,
        shadowOffset: { width: 0, height: 8 },
      },
    }),
  },
  planTitle: {
    color: '#F5F7F6',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 28,
  },
});
