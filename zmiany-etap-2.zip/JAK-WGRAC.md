# Etap 2: ekran główny (poprawki) + „Wybierz trening”

Ta paczka **zawiera też wszystko z etapu 1** — wystarczy wgrać tylko ją.
Rozpakuj w katalogu głównym projektu i nadpisz pliki.

| Plik | Co się zmienia |
|---|---|
| `src/app/(tabs)/training/index.tsx` | bez paska Pn–Nd; kafelki (tydzień / passa / minuty) **nad** kartą startu; karta startu zielona jak na obrazie 7; 🔥 z cyfrą w rogu; „Twoje plany” bez zmian miejsca |
| `src/components/workout-flow.tsx` | nowy układ: nagłówek → pasek „NA DZIŚ” → mapa mięśni (przód + tył, bieżący tydzień) z legendą → karuzela planów → 3 kafelki (od ostatniego treningu / planów / w tym tygodniu) |
| `src/components/plan-carousel.tsx` | karty planów w zielonym stylu karty startu; większe przyciski (44–46 px); logika karuzeli, edycji, usuwania i startu bez zmian |
| `src/components/workout-flow-glass-card.tsx` | ciemne, przezroczyste szkło (API bez zmian) |
| `src/components/muscle-engagement-map.tsx` | **dwie nowe opcjonalne właściwości**: `showViewToggle` (domyślnie `true`) i `height` (domyślnie `336`); dotychczasowe użycia działają jak wcześniej |
| `src/components/ambient-background.tsx` | tło: czerń + ostre zielone kręgi |
| `src/constants/glass-tokens.json` | dopisane tokeny ciemnego szkła i `heroCard` |
| `src/lib/workout-streak.ts` | **nowy**: passa i minuty w tym tygodniu |

Bez zmian: routing, `planId`, `use-gym-app`, zapis sesji, `completed_at`, logika `calculateMuscleVolume` i progi kolorów.

## Po wgraniu

```bash
npx tsc --noEmit
npx expo lint
npx expo start -c
```

## Co sprawdzić

**Ekran główny**
1. Na górze 🔥 z cyfrą obok ustawień (tylko przy passie ≥ 1).
2. Kolejność: powitanie → 3 kafelki → zielona karta „ZACZNIJ TRENING” → Twoje plany.
3. START i „Wszystkie” otwierają „Wybierz trening”.

**Wybierz trening**
4. Pasek „NA DZIŚ” startuje trening tego planu.
5. Mapa: dwie sylwetki obok siebie (PRZÓD / TYŁ), kolory jak w panelu analizy podczas treningu — porównaj z panelem „Tydzień” w aktywnym treningu, powinny się zgadzać.
6. Bez treningów w tym tygodniu: szare sylwetki + podpowiedź pod legendą.
7. Karuzela: przewijanie, kropki, edycja, usuwanie (z potwierdzeniem), Start.
8. Kafelki na dole; dolny pasek nawigacji nie zasłania ostatniego kafelka.
9. Wąski telefon (np. 360 px szerokości): sylwetki się mieszczą, pasek „NA DZIŚ” nie łamie się brzydko.

Nie mogłem uruchomić aplikacji ani `tsc` po swojej stronie — jeśli coś wyskoczy, wklej mi błąd.
