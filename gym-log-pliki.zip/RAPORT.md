# GYM LOG — pakiet do przeprojektowania

## Struktura projektu

Pliki aplikacji są w `src/`. Poniższe drzewo obejmuje maksymalnie trzy poziomy katalogów.

```text
src/app/
  +html.tsx
  _layout.tsx
  index.tsx
  create-workout.tsx
  workout-flow.tsx
  workout-session.tsx
  (auth)/
    _layout.tsx
    login.tsx
    register.tsx
  (tabs)/
    _layout.tsx
    account.tsx
    history.tsx
    training/
      index.tsx

src/components/
  ambient-background.tsx
  animated-icon.module.css
  animated-icon.tsx
  animated-icon.web.tsx
  app-bottom-bar.tsx
  app-tabs-new.tsx
  app-tabs.tsx
  auth-shell.tsx
  exercise-detail-modal.tsx
  exercise-info-modal.tsx
  exercise-picker-modal.tsx
  external-link.tsx
  glass-blur-context.ts
  glass-panel.tsx
  glass-screen.tsx
  glow-backdrop.tsx
  gradient-text.tsx
  hint-row.tsx
  muscle-engagement-map.tsx
  muscle-volume-panel.tsx
  neon-text.tsx
  plan-carousel.tsx
  themed-text.tsx
  themed-view.tsx
  web-badge.tsx
  workout-flow-glass-card.tsx
  workout-flow.tsx
  workout-ui.tsx
  ui/
    collapsible.tsx

src/hooks/
  use-auth.tsx
  use-color-scheme.ts
  use-color-scheme.web.ts
  use-gym-app.tsx
  use-theme.ts

src/lib/
  database.types.ts
  muscle-volume.ts
  nativewind-interop.ts
  supabase.ts
  workout-goal.ts

src/constants/
  exercise-library.ts
  glass-tokens.json
  gym-theme.ts
  muscle-volume.ts
  theme.ts
```

W repozytorium nie ma `app/(tabs)/index.tsx`. Ekran główny zakładki Treningi to `src/app/(tabs)/training/index.tsx`, routowany jako `/(tabs)/training`. `/workout-flow` jest osobnym ekranem „Wybierz trening”.

## Wersje i biblioteki

Wersje z manifestu `package.json`:

| Pakiet | Wersja |
|---|---:|
| Expo SDK | 58 (`expo` `^58.0.0`; uruchomiony CLI zgłosił zainstalowane `58.0.22`) |
| React Native | `0.88.1` |
| NativeWind | `4.2.7` |
| Tailwind CSS | `^3.4.17` |
| expo-router | `~58.0.29` |

| Biblioteka | Zainstalowana |
|---|---|
| `react-native-svg` | Tak (`15.16.0`) |
| `expo-blur` | Tak (`~58.0.5`) |
| `expo-linear-gradient` | Tak (`~58.0.3`) |
| `react-native-reanimated` | Tak (`4.7.1`) |
| `expo-haptics` | Nie |
| `expo-symbols` | Tak (`~58.0.4`) |

## Passa treningowa

Nie znaleziono logiki liczącej passę (dni ukończone z rzędu). Sesja przechowuje czas ukończenia w bazie jako `completed_at` (ISO 8601), np. `2026-11-13T18:25:00.000Z`; w typie aplikacji jest mapowany na `completedAt` (timestamp w milisekundach). Pole `date` jest sformatowanym tekstem do wyświetlania, a nie podstawowym znacznikiem czasu.

## Mapa mięśni

- Mapa SVG jest rysowana bezpośrednio w `src/components/muscle-engagement-map.tsx` przy użyciu `react-native-svg`; kształty figur są ścieżkami SVG w kodzie, nie osobnymi plikami graficznymi w `assets/`.
- Widok analizy serii znajduje się w aktywnym treningu (`src/app/workout-session.tsx` → `MuscleVolumePanel`). `MuscleEngagementMap` jest też używana w szczegółach ćwiczenia. Ekran `/workout-flow` pokazuje karuzelę i propozycję „Na dziś”, ale nie renderuje tej mapy.
- Mapowanie ćwiczeń na partie i ważenie serii: `src/lib/muscle-volume.ts` (`exerciseMuscleMappings`, `calculateMuscleVolume`). Dane ćwiczeń i ich partie pochodzą z `src/constants/exercise-library.ts`.
- Obsługiwane partie (19): klatka piersiowa, górna część klatki, najszersze grzbietu, górna/środkowa część pleców, czworoboczne, prostowniki grzbietu, przedni/boczny/tylny akton barków, biceps, triceps, przedramiona, czworogłowe uda, dwugłowe uda, pośladki, przywodziciele, łydki, brzuch i mięśnie skośne.
- Seria główna wnosi `1.0`, pomocnicza `0.5`. Liczone są ukończone serie; rozgrzewkowe i serie z RIR poza zakresem 0–3 są pomijane. Kolory statusów z `src/constants/muscle-volume.ts`: brak serii — szary (`#6B7A72`), poniżej zakresu — niebieski (`#3979D6`), zakres — zielony (`#79DD20`), wysoka objętość — czerwony (`#D94343`).
- Dostępne są zakresy dla bieżącej sesji i bieżącego tygodnia kalendarzowego (poniedziałek–niedziela, strefa czasowa urządzenia). Zakresy orientacyjne są zdefiniowane osobno dla każdej partii i okresu w `src/constants/muscle-volume.ts`; tygodniowy wykres sumuje ważone serie z ukończonych treningów w tym tygodniu oraz bieżącej sesji. To nie jest ruchome okno ostatnich 7×24 godzin.

## Ekran „Wybierz trening”

- Filtrowania planów nie ma. `PlanCarousel` pokazuje dostępne plany jako przewijaną karuzelę.
- „Na dziś” wybiera pierwszy plan, którego nazwa nie pojawiła się w ukończonych sesjach bieżącego tygodnia kalendarzowego; nie jest to harmonogram dni przypisany do planu.
- Edycja jest obsługiwana: `src/components/workout-flow.tsx` przekazuje plan do `src/app/create-workout.tsx` przez parametr `planId`; formularz ładuje plan i zapisuje zmiany przez `updatePlan` z `src/hooks/use-gym-app.tsx`.
- Usuwanie jest obsługiwane: akcja w `src/components/plan-carousel.tsx` wywołuje `confirmDeletePlan` w `src/components/workout-flow.tsx`; po potwierdzeniu `deletePlan` usuwa plan przez hook `useGymApp`.

## Elementy, których nie ruszać przy zmianach wizualnych

- Zachować route'y Expo Router, przekazywanie `planId` i nawigację: `/workout-flow`, `/workout-session`, `/create-workout` oraz `/(tabs)/training`.
- Nie zmieniać bez osobnej decyzji logiki zapisu/odczytu planów i sesji w `use-gym-app`, znacznika ukończenia `completed_at`, zapisu szkicu aktywnego treningu ani reguł ukończonych serii używanych przez analizę mięśni.
- Zachować kontrakty komponentów `PlanCarousel`, `MuscleVolumePanel` i `MuscleEngagementMap` oraz dostępne stany usuwania/błędów.
- Pliki konfiguracyjne dołączone do ZIP-a są kopią referencyjną; nie ma w niej `.env`, kluczy ani sekretów.
